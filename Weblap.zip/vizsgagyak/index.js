
        const apiUrl = "http://localhost/api/nevnapok/";

        function keresesDatum() {
            const datum = document.getElementById("datum").value;
            if (!datum) {
                document.getElementById("eredmeny").innerText = "Kérjük, adjon meg egy dátumot!";
                return;
            }
            fetch(`${apiUrl}?nap=${datum}`)
                .then(response => response.json())
                .then(data => megjelenitEredmeny(data))
                .catch(error => console.error("Hiba:", error));
        }

        function keresesNev() {
            const nev = document.getElementById("nev").value;
            if (!nev) {
                document.getElementById("eredmeny").innerText = "Kérjük, adjon meg egy nevet!";
                return;
            }
            fetch(`${apiUrl}?nev=${nev}`)
                .then(response => response.json())
                .then(data => megjelenitEredmeny(data))
                .catch(error => console.error("Hiba:", error));
        }

        function megjelenitEredmeny(data) {
            if (data.hiba) {
                document.getElementById("eredmeny").innerText = data.hiba;
            } else {
                document.getElementById("eredmeny").innerText = JSON.stringify(data, null, 2);
            }
        }
