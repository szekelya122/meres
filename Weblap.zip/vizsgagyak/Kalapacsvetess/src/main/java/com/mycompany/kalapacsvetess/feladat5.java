/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.kalapacsvetess;

import java.util.List;

/**
 *
 * @author bedov
 */
public class feladat5 {
    public static void feladat5(List<sportolo> sportolok) {
    double osszeg = 0;
    int magyarDobasok = 0;

    for (sportolo sportolo : sportolok) {
        if (sportolo.getOrszagKod().equals("HUN")) {
            osszeg += sportolo.getEredmeny();
            magyarDobasok++;
        }
    }

    if (magyarDobasok > 0) {
        double atlag = osszeg / magyarDobasok;
        System.out.printf("5. feladat: Magyar dobások átlaga: %.2f méter\n", atlag);
    } else {
        System.out.println("5. feladat: Nincsenek magyar dobások.");
    }
}

    
}
