/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.kalapacsvetess;
import java.io.*;
import java.util.*;
/**
 *
 * @author bedov

     */


public class AdatKezelo {
    public static List<sportolo> beolvas(String fajlNev) {
        List<sportolo> sportolok = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(fajlNev))) {
            String sor;
            br.readLine(); // Fejléc átugrása
            while ((sor = br.readLine()) != null) {
                String[] adatok = sor.split(";");
                int helyezes = Integer.parseInt(adatok[0]);
                double eredmeny = Double.parseDouble(adatok[1]);
                String nev = adatok[2];
                String orszagKod = adatok[3];
                String helyszin = adatok[4];
                String datum = adatok[5];
                sportolok.add(new sportolo(helyezes, eredmeny, nev, orszagKod, helyszin, datum));
            }
        } catch (IOException e) {
            System.err.println("Hiba a fájl beolvasása közben: " + e.getMessage());
        }
        return sportolok;
    }
    
    
    
    
    public static void feladat5(List<sportolo> sportolok) {
    double osszeg = 0;
    int magyarDobasok = 0;

    for (sportolo sportolo : sportolok) {
        if (sportolo.getOrszagKod().equals("HUN")) {
            osszeg += sportolo.getEredmeny();
            magyarDobasok++;
        }
    }

    if (magyarDobasok > 0) {
        double atlag = osszeg / magyarDobasok;
        System.out.printf("5. feladat: Magyar dobások átlaga: %.2f méter\n", atlag);
    } else {
        System.out.println("5. feladat: Nincsenek magyar dobások.");
    }
}
}

    

