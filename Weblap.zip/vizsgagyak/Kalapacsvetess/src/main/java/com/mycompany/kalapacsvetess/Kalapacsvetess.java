/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.kalapacsvetess;

/**
 *
 * @author bedov
 */
public class Kalapacsvetess {

    public static void main(String[] args) {
        
    }
}
