/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.kalapacsvetess;

/**
 *
 * @author bedov
 */
public class sportolo {

    sportolo(int helyezes, double eredmeny, String nev, String orszagKod, String helyszin, String datum) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    Object getOrszagKod() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    public class Sportolo {
    private int helyezes;
    private double eredmeny;
    private String nev;
    private String orszagKod;
    private String helyszin;
    private String datum;

    // Konstruktor
    public Sportolo(int helyezes, double eredmeny, String nev, String orszagKod, String helyszin, String datum) {
        this.helyezes = helyezes;
        this.eredmeny = eredmeny;
        this.nev = nev;
        this.orszagKod = orszagKod;
        this.helyszin = helyszin;
        this.datum = datum;
    }

    // Getterek
    public int getHelyezes() { return helyezes; }
    public double getEredmeny() { return eredmeny; }
    public String getNev() { return nev; }
    public String getOrszagKod() { return orszagKod; }
    public String getHelyszin() { return helyszin; }
    public String getDatum() { return datum; }

    public int getEv() {
        return Integer.parseInt(datum.split("\\.")[0]); // Az év kivonása a dátumból
    }
}

    
}
