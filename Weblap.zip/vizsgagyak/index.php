<?php
header("Content-Type: application/json");

// Adatbázis kapcsolat
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "nevnapok";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    echo json_encode(["hiba" => "Nem sikerült csatlakozni az adatbázishoz."]);
    exit();
}

// Paraméterek kezelése
if (isset($_GET['nap'])) {
    $nap = $conn->real_escape_string($_GET['nap']);
    $sql = "SELECT * FROM nevnapok WHERE datum = '$nap'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $data = $result->fetch_assoc();
        echo json_encode($data);
    } else {
        echo json_encode(["hiba" => "nincs találat"]);
    }
} elseif (isset($_GET['nev'])) {
    $nev = $conn->real_escape_string($_GET['nev']);
    $sql = "SELECT * FROM nevnapok WHERE nevnap1 = '$nev' OR nevnap2 = '$nev'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $data = $result->fetch_assoc();
        echo json_encode($data);
    } else {
        echo json_encode(["hiba" => "nincs találat"]);
    }
} else {
    echo json_encode([
        "minta1" => "/?nap=12-31",
        "minta2" => "/?nev=Szilveszter"
    ]);
}
$conn->close();
?>
