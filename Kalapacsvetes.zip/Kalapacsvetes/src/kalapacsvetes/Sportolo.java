/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kalapacsvetes;

import static java.lang.reflect.Array.get;

/**
 *
 * @author Ármin
 */
public class Sportolo {
    private String nev;
    private String orszag;
    private int ev;
    private double dobásEredmény;

    // Konstruktor
    public Sportolo(String nev, String orszag, int ev, double dobásEredmény) {
        this.nev = nev;
        this.orszag = orszag;
        this.ev = ev;
        this.dobásEredmény = dobásEredmény;
    }

    // Getterek
    public String getNev() {
        return nev;
    }

    public String getOrszag() {
        return orszag;
    }

    public int getEv() {
        return ev;
    }

    public double getDobásEredmény() {
        return dobásEredmény;
    }

    // ToString metódus a kiíráshoz
    @Override
    public String toString() {
        return nev + " (" + orszag + ") - " + ev + ": " + dobásEredmény + " m";
    }
    
    
   

}