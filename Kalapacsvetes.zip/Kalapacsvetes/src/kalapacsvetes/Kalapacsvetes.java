/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package kalapacsvetes;

import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

public class Kalapacsvetes {

    public static void main(String[] args) {
        List<Sportolo> sportolok = new ArrayList<>();

        // 3. Lépés: Fájl beolvasása
        try (BufferedReader br = new BufferedReader(new FileReader("kalapacsvetes.txt"))) {
            String sor;
            br.readLine(); // Fejléc átugrása
            while ((sor = br.readLine()) != null) {
                String[] adatok = sor.split("\t");
                if (adatok.length == 4) {
                    String nev = adatok[0];
                    String orszag = adatok[1];
                    int ev = Integer.parseInt(adatok[2]);
                    double dobásEredmény = Double.parseDouble(adatok[3]);

                    sportolok.add(new Sportolo(nev, orszag, ev, dobásEredmény));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // 4. Lépés: A dobások számának meghatározása
        System.out.println("A fájlban szereplő dobások száma: " + sportolok.size());

        // 5. Lépés: A magyar sportolók átlagos dobásának kiszámítása
        double atlag = sportolok.stream()
                .filter(s -> "HUN".equals(s.getOrszag()))
                .mapToDouble(Sportolo::getDobásEredmény)
                .average()
                .orElse(0.0);

        System.out.printf("A magyar sportolók dobásainak átlagos eredménye: %.2f m%n", atlag);

        // 6. Lépés: Kérjünk be egy évszámot és jelenítsük meg a legjobb dobásokat
        Scanner scanner = new Scanner(System.in);
        System.out.print("Kérlek, adj meg egy évszámot: ");
        int keresettEv = scanner.nextInt();

        List<Sportolo> legjobbak = sportolok.stream()
                .filter(s -> s.getEv() == keresettEv && s.getDobásEredmény() == sportolok.stream()
                        .filter(ss -> ss.getEv() == keresettEv)
                        .mapToDouble(Sportolo::getDobásEredmény)
                        .max()
                        .orElse(0.0))
                .collect(Collectors.toList());

        if (legjobbak.isEmpty()) {
            System.out.println("Ebben az évben nem került be egy dobás sem a legjobbak közé.");
        } else {
            System.out.println("A legjobb dobások " + keresettEv + "-ban:");
            for (Sportolo legjobb : legjobbak) {
                System.out.println(legjobb);
            }
        }

        // 7. Lépés: Statisztika a legjobb dobásokról ország szerint
        Map<String, Long> statisztika = sportolok.stream()
                .filter(s -> s.getDobásEredmény() == sportolok.stream()
                        .mapToDouble(Sportolo::getDobásEredmény)
                        .max()
                        .orElse(0.0))
                .collect(Collectors.groupingBy(Sportolo::getOrszag, Collectors.counting()));

        System.out.println("\nA legjobb dobások országok szerint:");
        for (Map.Entry<String, Long> entry : statisztika.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue() + " db");
        }

        // 8. Lépés: Magyar sportolók adatainak kiírása egy fájlba
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("magyarok.txt"))) {
            for (Sportolo sportolo : sportolok) {
                if ("HUN".equals(sportolo.getOrszag())) {
                    writer.write(sportolo.toString());
                    writer.newLine();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


    
    

